const ftoc = function() {

};

const ctof = function() {

};

module.exports = {
  ftoc,
  ctof
};
