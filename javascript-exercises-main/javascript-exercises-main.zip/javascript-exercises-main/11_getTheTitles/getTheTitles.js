const getTheTitles = function() {

};

module.exports = getTheTitles;
