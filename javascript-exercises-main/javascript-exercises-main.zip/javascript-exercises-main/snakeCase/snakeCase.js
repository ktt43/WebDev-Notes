const snakeCase = function() {

};

module.exports = snakeCase;
