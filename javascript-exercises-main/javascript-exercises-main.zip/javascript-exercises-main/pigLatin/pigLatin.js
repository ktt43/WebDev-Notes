function pigLatin(string) {

};
  
  module.exports = pigLatin;
