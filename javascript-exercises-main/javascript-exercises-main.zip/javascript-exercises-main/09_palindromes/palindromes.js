const palindromes = function () {

};

module.exports = palindromes;
