const repeatString = function() {

};

module.exports = repeatString;
