const add = function() {
	
};

const subtract = function() {
	
};

const sum = function() {
	
};

const multiply = function() {

};

const power = function() {
	
};

const factorial = function() {
	
};

module.exports = {
  add,
  subtract,
  sum,
  multiply,
  power,
  factorial
};
