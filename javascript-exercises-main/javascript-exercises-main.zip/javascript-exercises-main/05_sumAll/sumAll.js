const sumAll = function() {

};

module.exports = sumAll;
